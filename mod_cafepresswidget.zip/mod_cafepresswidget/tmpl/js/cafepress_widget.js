window.cpProductsWidget.init = function(){
  var liwidth = $$('div#cpwidget ul.products')[0].getDimensions()['width'];
  var ulwidth = liwidth *  $$('div#cpwidget ul.products li').length;
  
  $$('div#cpwidget ul.products li').each(function(item, index){
    item.setStyle("width",liwidth);
  });
  
  $$('div#cpwidget ul.products')[0].setStyles({
    "width": ulwidth,
    "left": -200
  });
  
  try {
    var anav = $$('div#cpwidget a.nav');
    anav.setStyles({
      'opacity': 0,
      'display': 'block'
    });
    
    $$('div#cpwidget')[0].addEvents({
      mouseover: function(){
        window.cpProductsWidget.is_inside = true;
        anav.morph({
          'opacity': 1,
          duration: 200,
          transition: Fx.Transitions.Sine.easeOut,
          link : 'cancel'
        });        
      },
      mouseleave: function(){
        window.cpProductsWidget.is_inside = false;
        anav.morph({
          'opacity': 0,
          duration: 200,
          transition: Fx.Transitions.Sine.easeOut,
          link : 'cancel'
        });        
      }
    });
    
    
    $$('div#cpwidget').getElement('a.next').addEvent('click', function(event){
      event.stopPropagation();
      window.cpProductsWidget.animate_next();
    });
    
    $$('div#cpwidget').getElement('a.prev').addEvent('click', function(event){
      event.stopPropagation();
      window.cpProductsWidget.animate_prev();
    });
    
  } catch (e) {
    
  }
  
  //set now the auto interval
  window.cpProductsWidget.auto_scroll = setInterval(function(){
    if (window.cpProductsWidget.is_inside) return true;
    window.cpProductsWidget.animate_next();
  }, 3000);
}



//next button
window.cpProductsWidget.animate_next = function (){
  window.cpProductsWidget.animate_done = true;
  
  // inject the first li element after the last li element Note: getLast and First is buggy during the time of writing
  $$('div#cpwidget ul.products li')[0].inject( $$('div#cpwidget ul.products li')[$$('div#cpwidget ul.products li').length - 1] , 'after' );
  
  //get the first value since it has changed
  var first = $$('div#cpwidget ul.products li')[0];
  first.setStyle( "margin-left", 200 );
  
  first.morph({
    "margin-left": [200, 0],
    duration: 500,
    transition: Fx.Transitions.Sine.easeOut,
    "complete" : function(){
      window.cpProductsWidget.animate_done = false;
    }
  });
    
  return true;
}

//next button
window.cpProductsWidget.animate_prev = function (){
  window.cpProductsWidget.animate_done = true;
  
  //get the first value since it has changed
  var last = $$('div#cpwidget ul.products li')[$$('div#cpwidget ul.products li').length - 1];
  last.setStyle( "margin-left", -200 );
  last.inject($$('div#cpwidget ul.products li')[0],'before');
    
  last.morph({
    "margin-left": [-200, 0],
    duration: 500,
    transition: Fx.Transitions.Sine.easeOut,
    "complete" : function(){
      window.cpProductsWidget.animate_done = false;
    }
  });
    
  return true;
}
window.addEvent('load', function(){
  window.cpProductsWidget.animate_done = false;
  window.cpProductsWidget.is_inside = false;
  //trigger the js
  window.cpProductsWidget.init();
});
