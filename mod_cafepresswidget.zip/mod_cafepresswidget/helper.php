<?php
/**
 * 
 * @package    Cafepress Widget
 * @subpackage Modules
 * @link http://dev.joomla.org/component/option,com_jd-wiki/Itemid,31/id,tutorials:modules/
 * @license        GNU/GPL, see LICENSE.php
 * mod_cafepress is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
class modCafepressWidgetHelper
{
	/**
	 * Retrieves the widget
	 * @param array $params An object containing the module parameters
	 * @access public
	 */    
	function getWidget( $params )
	{
    # Available parameters
    //$params->get('cafepresswidget_title'); -- removed
    //$params->get('cafepresswidget_aid');
    //$params->get('cafepresswidget_products');
    //$params->get('cafepresswidget_productsoption');

    $widget_html = "";
    
    $now  = strtotime('now');
    $instance['theme'] = $params->get('cafepresswidget_theme'); 
    
    #default values for now
    if (empty($instance['cols'])) $instance['cols'] = 25;
    if (empty($instance['rows'])) $instance['rows'] = 1;
    
    $query['products'] ="";
   
    $cp_product_type = trim($params->get('cafepresswidget_products'));
    $cp_config = trim($params->get('cafepresswidget_aid'));
    $cp_filters = trim($params->get('cafepresswidget_productsoption'));
    //build the products query
    if ($cp_product_type == 'shop') {
      $query['products'] = 'shop:'. $cp_config;
      if ( $cp_filters != '') $query['products'] = $query['products'] . '|' . $cp_filters;
    } else {
      $query['products'] = "tags:". $cp_filters;
      $affiliateid = $cp_config;
      if ($affiliateid != '') $query['products']  = $query['products']  . '|' . $affiliateid;
    }//endif
    
    //self::dump($query);
    
    //fetch the data
    $instance['cafepress']['json']   = self::api($query['products'], array('resultsPerPage' => ($instance['cols']  * $instance['rows']) ));
    
    //self::dump($instance);
    //return an empty string if we did not get any value
    if(empty($instance['cafepress']['json']['resultcount'])) 
      return $widget_html;
    
    $url = CAFEPRESS_WIDGET_URL;
    $doc 		=& JFactory::getDocument();
    $doc->addStyleSheet( CAFEPRESS_WIDGET_CSS_URL  );
    
    $liproducts = array();
      foreach ($instance['cafepress']['json']['product'] as $k => $v) 
      {
        if ($v['price']{0} != '$')
            $v['price'] = "&#36;{$v['price']}";
            
        $liproducts[] = <<<LIPRODUCT
<li>
<a href="{$v['linkurl']}" class="img"><img  width="160" height="160" src="{$v['imageurl']}" ></a>
<a href="{$v['linkurl']}" class="descr">
  {$v['caption']} <b>{$v['price']}</b>
</a>
</li>
LIPRODUCT;
      }// end foreach
      //self::dump( $instance);
      $liproducts = implode('', $liproducts);

      $widget_html .= <<<HTML
<div id="cpwidget" class="CafePressWidget" >
<div class="products">
<ul class="products">
    {$liproducts}
</ul>
</div>
<a class="nav prev"></a>
<a class="nav next"></a>
<div class="toolbar {$instance['theme']}">
    <img src="http://widgets.cafepress.com/images/jmwidget.png?cb={$now}" border="0" style="display:none" />
    <a class="cafepress" href="http://www.cafepress.com?CMP=jmwidget_logo&utm_campaign=jmwidget&utm_medium=seo&utm_source=image_click_logo">CafePress.com</a>
    <a class="shopshop" href="{$instance['cafepress']['json']['seeallurl']}">SHOPSHOP</a>
</div>
</div>
HTML;
    
    $widget_html .= <<<JSCRIPT
<script type="text/javascript">
window.cpProductsWidget = {
    "path" : "{$url}",
    "init" : function() {},
    "cols" : "{$instance['cols']}",
    "rows" : "{$instance['rows']}"
};
(function() {
var e = document.createElement('script');
e.src = '{$url}/js/cafepress_widget.js';
e.async = true;
document.getElementById('cpwidget').appendChild(e);
}());
</script>
JSCRIPT;
    
    //$widget_html = $widget_html . $params['cafepresswidget_title'];
    return $widget_html ;
	}
  
  /**
   * Api fetch for the cafepress products
   */
  private function api($query, $options = array()) {
    //$query      = 'qfoobar';
    $resultsPerPage = 25;
    $tracking       = 'joomla';
    unset($options['query']);
    extract($options, EXTR_IF_EXISTS);

    if ($resultsPerPage < 0) $resultsPerPage = 25;

    $parameters = array(
        'resultsPerPage'    => $resultsPerPage,
        'tracking'          => $tracking
    );

    $type = 'all';
    error_reporting(E_ALL ^ E_NOTICE);
    
     switch (true) {
      case preg_match('/^shop:/', $query):
        list($type, $dump) = explode(":", $query, 2);
        list($shopname, $filter) = explode('|', $dump);

        $query = trim($query);
        $url = CAFEPRESS_API_URLPATH ."/{$type}/{$shopname}/{$filter}?";
        break;

      default:
        $type = 'all';
        list(, $dump) = explode(":", $query, 2);
        list($query, $affiliateid) = explode('|', $dump);

        $query = trim($query);
        $url = CAFEPRESS_API_URLPATH ."/{$type}/{$query}?";
        break;
    }// end switch

    //$query = trim($query);
    
    $ch     = curl_init();
    $url    = $url.http_build_query($parameters);
    //echo $url;
    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_TIMEOUT, 24);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 9);
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');

    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HEADER, false);

    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_REFERER']);
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);

    $header = array();
    $header[] = "Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,* /*;q=0.5";
    $header[] = "Cache-Control: max-age=0";
    $header[] = "Connection: keep-alive";
    $header[] = "Keep-Alive: 300";
    $header[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $header[] = "Accept-Language: en-us,en;q=0.5";
    $header[] = "Pragma: ";

    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $response   = curl_exec($ch);
    $curlerror  = array(curl_errno($ch), curl_error($ch));

    curl_close($ch);
    if (empty($response)) return false;


    $json = @json_decode($response, true);

    if ($json === false) return false;

    /**
     * append affiliate id if not empty
     */
    if (!empty($affiliateid)) {
        $json['seeallurl'] = "{$json['seeallurl']}&aid={$affiliateid}";
        foreach ($json['product'] as $k => $v) {
            $json['product'][$k]['linkurl'] = "{$v['linkurl']}&aid={$affiliateid}";
        }// end foreach
    }//end if
    
    return $json;
  } //end function
  
  function dump($var) {
		echo "<!-- cp_widget \n";
		print_r($var);
		echo "--!>";
	}
}
?>