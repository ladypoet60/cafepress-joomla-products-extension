<?php
/**
* @version		1.0.1
* @package		Joomla
* @copyright	Copyright (C) 2010 SP CYEND. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Import library dependencies
jimport('joomla.plugin.plugin');


$plugin =& JPluginHelper::getPlugin('editors-xtd', 'cafepressb');
$plugin_params = new JParameter( $plugin->params );

if (!defined('CAFEPRESS_TINYMCE_JS_URL'))
  define('CAFEPRESS_TINYMCE_JS_URL', JURI::root().'plugins/editors-xtd/cafepressb/cafepressb.js' );
/**
* Custom html button
*/
class plgButtonCafepressB extends JPlugin
{

    function plgButtonCafepressB( &$subject, $config) {
        parent::__construct($subject, $config);
    }

    function onDisplay($name)
    {

			//create instance of the document
			$doc 		=& JFactory::getDocument();
	
			// button is not active in specific content components
			$getContent = $this->_subject->getContent($name);
						
			$js = "
				
				function cafepressButton(editor) {
					cafepressb_tinymce = editor; // store a reference for updating the contents later
					var content = $getContent
					//alert (content);
					SqueezeBox.open($('cafepressb_form'), {
						handler: 'clone',
						size: {x: 360, y: 410}
					});
				}
				";
	
			$doc->addScriptDeclaration($js);
			$doc->addScript( CAFEPRESS_TINYMCE_JS_URL );
			
  		$button = new JObject();
  		$button->set('modal', false);
  		$button->set('onclick', 'javascript:cafepressButton(\''.$name.'\');return false;');
  		$button->set('text', JText::_('Cafepress'));
  		$button->set('name', 'blank');
  		$button->set('link', '#');
			
  		return $button;
   }

}
