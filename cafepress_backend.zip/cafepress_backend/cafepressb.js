window.addEvent('domready', function() {
	var cafepressb_tinymce;
	var cafepressb_div = new Element('div#cafepressb_div', { 
    html : 	"<div id='cafepressb_form'>" +
            "<form id='cafepress_form_content' name='cafepress_form_content'>"+
            "<strong>Cafepress Plugin Configuration</strong><br />"+
            "<select name='cp_product_type'><option value='shop'>Shop ID</option><option value='affiliate'>Affiliate ID</option></select><br /><br />"+
            "<strong>Provide the affiliate id or shop id</strong><br />"+
            '<i>optional info, depends on what configuration is selected</strong></i><br />' +
            '<input id="cp_product_config" name="cp_product_config" type="text" size="40" maxlength="100" value="" style="font-size:12px; padding: 3px;" /><br /><br />'+
            '<strong>Enter Design Id or Tag:</strong><br />' +
            '<i>use comma for multiple designs</strong></i><br />' +
            '<input id="cp_filters" name="cp_filters" type="text" size="40" maxlength="100" value="" style="font-size:12px; padding: 3px;" /><br />'+
            '<br /><strong>CafePress Gallery Size</strong>'+
            '<table border="0" cellpadding="4" cellspacing="0">'+
              '<tr>'+
                '<td><label for="cafepress_cols">Columns</label></td>'+
                '<td><input id="cafepress_cols" name="cafepress_cols" type="text" size="2" maxlength="3" value="3" /></td>'+
              '</tr>'+
              '<tr>'+
                '<td><label for="cafepress_rows">Rows</label></td>'+
                '<td><input id="cafepress_rows" name="cafepress_rows" type="text" size="2" maxlength="3" value="2" /></td>'+
              '</tr>'+
            '</table><br />'+
            '<div class="mceActionPanel">'+
            '<div style="float: left">'+
              '<input type="button" id="cancel" name="cancel" value="Cancel" onClick="SqueezeBox.close();" />'+
            '</div>'+
            '<div style="float: right">'+
              '<input type="button" id="insert" name="insert" value="Insert" onClick="cafepress_code_insert();" />'+
            '</div>'+
            '</div>'+
            '</p>'+
            "</form>"+
            "</div>",
    styles: {
      display: 'none'
    }
			
  });
	$(document.body).grab(cafepressb_div);
});

function cafepress_code_insert() {
  var cp_product_type = $('sbox-content').getElement('select[name=cp_product_type]').value;
  var cp_cols = $('sbox-content').getElement('input[name=cafepress_cols]').value;
  var cp_rows = $('sbox-content').getElement('input[name=cafepress_rows]').value;
  var cp_config = $('sbox-content').getElement('input[name=cp_product_config]').value;
  var cp_filters= $('sbox-content').getElement('input[name=cp_filters]').value;
 
  var str = '[cafepress';
  var products ="";
  if (cp_product_type == 'shop') {
    products = 'shop:'+ cp_config.trim();
    if ( cp_filters.trim() != '') products = products + '|' + cp_filters.trim();
  } else  {
    products = "tags:"+ cp_filters.trim();
    var affiliateid = cp_config.trim();
    if (affiliateid != '') products = products + '|' + affiliateid;
  }

  if (products != '' )
    str += ' products=`'+products+'`';

  if (cp_cols.trim() != '')
    str += ' cols=`'+ cp_cols.trim() +'`';
  
  if (cp_rows.trim() != '')
    str += ' rows=`'+ cp_rows.trim() +'`';
  
 
  
	str += ']';
  jInsertEditorText(str, cafepressb_tinymce);
  SqueezeBox.close();
}
